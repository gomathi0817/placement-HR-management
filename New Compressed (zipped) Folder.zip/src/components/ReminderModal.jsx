import React, { useState } from 'react';
import { Bell, Phone, CheckCircle2, Calendar, X, Mail, MessageCircle, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const ReminderModal = () => {
  const { activeReminder, setActiveReminder, markFollowUpComplete, rescheduleFollowUp } = useApp();
  const [showReschedule, setShowReschedule] = useState(false);
  const [newDate, setNewDate] = useState('');
  const [newTime, setNewTime] = useState('10:30 AM');
  const [showContactMenu, setShowContactMenu] = useState(false);

  if (!activeReminder) return null;

  const { followUp, hr } = activeReminder;

  const handleComplete = () => {
    markFollowUpComplete(followUp.id);
    setActiveReminder(null);
  };

  const handleRescheduleSubmit = (e) => {
    e.preventDefault();
    if (!newDate) return;
    rescheduleFollowUp(followUp.id, newDate, newTime);
    setActiveReminder(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white border-2 border-[#4E220F] rounded-3xl max-w-md w-full overflow-hidden shadow-gv-modal transform transition-all animate-scaleUp">
        {/* Header Bar */}
        <div className="bg-[#4E220F] text-[#F3CD97] p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#F3CD97] text-[#4E220F] flex items-center justify-center font-bold animate-bounce shadow-sm">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base leading-tight">Placement Follow-Up Reminder</h3>
              <span className="text-[11px] text-[#F3CD97]/80">Active Action Alert</span>
            </div>
          </div>
          <button
            onClick={() => setActiveReminder(null)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4 bg-gradient-to-b from-[#FAF4EB] to-white">
          {/* HR Profile Banner */}
          <div className="flex items-center gap-4 bg-white p-3.5 rounded-2xl border border-[#C8A96B]/30 shadow-xs">
            <img
              src={hr?.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200"}
              alt={followUp.hrName}
              className="w-14 h-14 rounded-2xl object-cover border-2 border-[#C8A96B]"
            />
            <div>
              <h4 className="font-bold text-base text-[#4E220F] leading-tight">
                {followUp.hrName}
              </h4>
              <p className="text-xs font-semibold text-[#785642]">
                {followUp.companyName}
              </p>
              <span className="inline-block mt-1 text-[10px] font-bold bg-[#F3CD97]/40 text-[#4E220F] px-2 py-0.5 rounded-md">
                {hr?.designation || "Talent Acquisition Lead"}
              </span>
            </div>
          </div>

          {/* Details */}
          <div className="bg-[#FAF4EB] border border-[#C8A96B]/40 rounded-2xl p-4 space-y-2 text-xs">
            <div className="flex justify-between items-center pb-2 border-b border-[#C8A96B]/20">
              <span className="font-bold text-[#785642] uppercase text-[10px]">Action Required</span>
              <span className="font-bold text-[#4E220F] bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full flex items-center gap-1">
                <Phone className="w-3 h-3" /> Call HR
              </span>
            </div>

            <div className="flex justify-between items-center">
              <span className="font-bold text-[#785642]">Scheduled Time:</span>
              <span className="font-bold text-[#4E220F] flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-[#C8A96B]" /> {followUp.time || "10:30 AM"}
              </span>
            </div>

            <div>
              <span className="font-bold text-[#785642] block mb-1">Purpose:</span>
              <p className="text-sm font-semibold text-[#4E220F] bg-white p-2.5 rounded-xl border border-[#C8A96B]/30">
                "{followUp.purpose}"
              </p>
            </div>
          </div>

          {/* Reschedule Form Toggle */}
          {showReschedule ? (
            <form onSubmit={handleRescheduleSubmit} className="bg-white p-3 rounded-2xl border border-[#C8A96B] space-y-2">
              <span className="text-xs font-bold text-[#4E220F] block">Select New Date & Time</span>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="date"
                  required
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full text-xs p-2 border border-[#C8A96B] rounded-lg"
                />
                <input
                  type="text"
                  value={newTime}
                  onChange={(e) => setNewTime(e.target.value)}
                  placeholder="10:30 AM"
                  className="w-full text-xs p-2 border border-[#C8A96B] rounded-lg"
                />
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowReschedule(false)}
                  className="px-3 py-1.5 text-xs text-[#785642] font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-[#4E220F] text-[#F3CD97] text-xs font-bold rounded-lg shadow"
                >
                  Save Reschedule
                </button>
              </div>
            </form>
          ) : showContactMenu ? (
            <div className="bg-white p-3.5 rounded-2xl border border-[#C8A96B] space-y-2 animate-fadeIn">
              <span className="text-xs font-bold text-[#4E220F] block">Choose Contact Method</span>
              <div className="grid grid-cols-3 gap-2">
                <a
                  href={`tel:${hr?.phone || '+919876543210'}`}
                  className="flex flex-col items-center justify-center p-2.5 bg-emerald-50 text-emerald-800 rounded-xl hover:bg-emerald-100 font-bold text-xs border border-emerald-200"
                >
                  <Phone className="w-4 h-4 mb-1" />
                  <span>Call</span>
                </a>
                <a
                  href={`https://wa.me/${hr?.phone ? hr.phone.replace(/[^0-9]/g, '') : '919876543210'}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex flex-col items-center justify-center p-2.5 bg-emerald-50 text-emerald-800 rounded-xl hover:bg-emerald-100 font-bold text-xs border border-emerald-200"
                >
                  <MessageCircle className="w-4 h-4 mb-1 text-emerald-600" />
                  <span>WhatsApp</span>
                </a>
                <a
                  href={`mailto:${hr?.email || 'hr@example.com'}`}
                  className="flex flex-col items-center justify-center p-2.5 bg-blue-50 text-blue-800 rounded-xl hover:bg-blue-100 font-bold text-xs border border-blue-200"
                >
                  <Mail className="w-4 h-4 mb-1 text-blue-600" />
                  <span>Email</span>
                </a>
              </div>
              <button
                type="button"
                onClick={() => setShowContactMenu(false)}
                className="w-full text-center text-xs font-semibold text-[#785642] pt-1"
              >
                Back to options
              </button>
            </div>
          ) : null}

          {/* Action Buttons */}
          {!showReschedule && !showContactMenu && (
            <div className="grid grid-cols-3 gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowContactMenu(true)}
                className="py-3 px-2 bg-[#4E220F] hover:bg-[#7A3517] text-[#F3CD97] font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5"
              >
                <Phone className="w-4 h-4" />
                <span>Call HR</span>
              </button>

              <button
                type="button"
                onClick={handleComplete}
                className="py-3 px-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Mark Done</span>
              </button>

              <button
                type="button"
                onClick={() => setShowReschedule(true)}
                className="py-3 px-2 bg-[#FAF4EB] border border-[#C8A96B] hover:bg-[#C8A96B]/20 text-[#4E220F] font-bold text-xs rounded-xl flex items-center justify-center gap-1.5"
              >
                <Calendar className="w-4 h-4" />
                <span>Reschedule</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
