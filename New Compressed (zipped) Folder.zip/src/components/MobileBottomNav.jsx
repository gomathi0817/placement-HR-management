import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Users, Clock, User, Plus } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const MobileBottomNav = () => {
  const { setIsQuickAddOpen } = useApp();

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t-2 border-[#C8A96B]/50 px-3 py-2 shadow-lg">
      <div className="flex items-center justify-around relative">
        {/* Dashboard */}
        <NavLink
          to="/dashboard"
          className={({ isActive }) => `
            flex flex-col items-center justify-center text-[10px] font-bold py-1 px-3 transition-colors
            ${isActive ? 'text-[#4E220F]' : 'text-[#785642] hover:text-[#4E220F]'}
          `}
        >
          <LayoutDashboard className="w-5 h-5 mb-0.5" />
          <span>Dashboard</span>
        </NavLink>

        {/* HR Contacts */}
        <NavLink
          to="/hr"
          className={({ isActive }) => `
            flex flex-col items-center justify-center text-[10px] font-bold py-1 px-3 transition-colors
            ${isActive ? 'text-[#4E220F]' : 'text-[#785642] hover:text-[#4E220F]'}
          `}
        >
          <Users className="w-5 h-5 mb-0.5" />
          <span>HR</span>
        </NavLink>

        {/* Central Emphasized Floating Add Button */}
        <div className="-mt-7 relative z-10">
          <button
            onClick={() => setIsQuickAddOpen(true)}
            aria-label="Add Record"
            className="w-14 h-14 rounded-full bg-[#4E220F] text-[#F3CD97] flex items-center justify-center shadow-lg border-4 border-white hover:scale-105 active:scale-95 transition-all"
          >
            <Plus className="w-7 h-7" />
          </button>
        </div>

        {/* Follow-Ups */}
        <NavLink
          to="/follow-ups"
          className={({ isActive }) => `
            flex flex-col items-center justify-center text-[10px] font-bold py-1 px-3 transition-colors
            ${isActive ? 'text-[#4E220F]' : 'text-[#785642] hover:text-[#4E220F]'}
          `}
        >
          <Clock className="w-5 h-5 mb-0.5" />
          <span>Follow-Ups</span>
        </NavLink>

        {/* Profile / Settings */}
        <NavLink
          to="/settings"
          className={({ isActive }) => `
            flex flex-col items-center justify-center text-[10px] font-bold py-1 px-3 transition-colors
            ${isActive ? 'text-[#4E220F]' : 'text-[#785642] hover:text-[#4E220F]'}
          `}
        >
          <User className="w-5 h-5 mb-0.5" />
          <span>Profile</span>
        </NavLink>
      </div>
    </div>
  );
};
