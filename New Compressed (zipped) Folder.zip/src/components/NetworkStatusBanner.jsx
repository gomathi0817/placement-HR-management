import React, { useState, useEffect } from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { checkHealth } from '../services/api';

export function NetworkStatusBanner() {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [backendStatus, setBackendStatus] = useState('online'); // 'online' | 'offline' | 'checking'

  const testBackend = async () => {
    setBackendStatus('checking');
    try {
      const res = await checkHealth();
      if (res && res.status === 'ok') {
        setBackendStatus('online');
      } else {
        setBackendStatus('offline');
      }
    } catch {
      setBackendStatus('offline');
    }
  };

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      testBackend();
    };
    const handleOffline = () => {
      setIsOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check on mount
    testBackend();

    // Periodic check every 30s
    const interval = setInterval(testBackend, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, []);

  if (!isOffline && backendStatus === 'online') {
    return null;
  }

  return (
    <div className="bg-amber-900/90 text-amber-100 text-xs py-1.5 px-4 flex items-center justify-between shadow-md z-50">
      <div className="flex items-center gap-2">
        <WifiOff size={14} className="animate-pulse text-amber-300" />
        <span>
          {isOffline
            ? 'No Internet connection. Working in offline fallback mode.'
            : 'Backend API server unavailable. Displaying cached data.'}
        </span>
      </div>
      <button
        onClick={testBackend}
        disabled={backendStatus === 'checking'}
        className="flex items-center gap-1 bg-amber-800 hover:bg-amber-700 text-amber-100 px-2 py-0.5 rounded text-[10px] font-medium transition-colors"
      >
        <RefreshCw size={10} className={backendStatus === 'checking' ? 'animate-spin' : ''} />
        {backendStatus === 'checking' ? 'Checking...' : 'Retry'}
      </button>
    </div>
  );
}

export default NetworkStatusBanner;
