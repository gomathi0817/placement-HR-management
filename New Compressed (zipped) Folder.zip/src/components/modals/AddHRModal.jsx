import React, { useState } from 'react';
import { X, User, Building2, Phone, Mail, MessageCircle, Briefcase, MapPin, Award } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const AddHRModal = ({ isOpen, onClose }) => {
  const { addHR, companies } = useApp();

  const [formData, setFormData] = useState({
    name: '',
    companyName: '',
    designation: 'Manager — Talent Acquisition',
    phone: '',
    email: '',
    whatsapp: '',
    status: 'Active',
    recruitmentType: 'Full-Time + Internship',
    studentsRequired: 20,
    jobRoles: 'Software Engineer Trainee',
    location: 'Bengaluru',
    nextFollowUpDate: '',
    nextFollowUpTime: '10:30 AM',
    nextFollowUpPurpose: 'Initial campus recruitment discussion'
  });

  const [errors, setErrors] = useState({});

  if (!isOpen) return null;

  const validate = () => {
    const errs = {};
    if (!formData.name.trim()) errs.name = 'HR Name is required';
    if (!formData.companyName.trim()) errs.companyName = 'Company name is required';
    if (!formData.phone.trim() && !formData.email.trim()) {
      errs.contact = 'Either phone or email must be provided';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;

    addHR({
      ...formData,
      jobRoles: formData.jobRoles.split(',').map(r => r.trim()),
      whatsapp: formData.whatsapp || formData.phone,
      companyInfo: {
        recruitmentType: formData.recruitmentType,
        studentsRequired: Number(formData.studentsRequired) || 0,
        jobRoles: formData.jobRoles.split(',').map(r => r.trim()),
        location: formData.location,
        currentStatus: 'Initial Outreach'
      }
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white border-2 border-[#4E220F] rounded-3xl max-w-lg w-full max-h-[90vh] overflow-hidden shadow-gv-modal flex flex-col">
        {/* Header */}
        <div className="bg-[#4E220F] text-[#F3CD97] p-5 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#F3CD97] text-[#4E220F] flex items-center justify-center font-bold">
              +
            </div>
            <div>
              <h3 className="font-bold text-base">Add New HR Contact</h3>
              <span className="text-[11px] text-[#F3CD97]/80">Register recruiter profile & company link</span>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto bg-[#FAF4EB]/40 flex-1">
          {errors.contact && (
            <div className="p-3 bg-red-100 border border-red-300 text-red-800 text-xs rounded-xl font-semibold">
              ⚠️ {errors.contact}
            </div>
          )}

          {/* HR Name & Designation */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#4E220F] mb-1">
                HR Name <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Gomathi HR"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl focus:ring-2 focus:ring-[#4E220F] outline-none"
              />
              {errors.name && <span className="text-[10px] text-red-600 font-bold">{errors.name}</span>}
            </div>

            <div>
              <label className="block text-xs font-bold text-[#4E220F] mb-1">
                Designation
              </label>
              <input
                type="text"
                placeholder="e.g. Manager — Talent Acquisition"
                value={formData.designation}
                onChange={e => setFormData({ ...formData, designation: e.target.value })}
                className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl focus:ring-2 focus:ring-[#4E220F] outline-none"
              />
            </div>
          </div>

          {/* Company Name */}
          <div>
            <label className="block text-xs font-bold text-[#4E220F] mb-1">
              Company Name <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              required
              list="existing-companies"
              placeholder="e.g. ABC Technologies"
              value={formData.companyName}
              onChange={e => setFormData({ ...formData, companyName: e.target.value })}
              className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl focus:ring-2 focus:ring-[#4E220F] outline-none"
            />
            <datalist id="existing-companies">
              {companies.map(c => <option key={c.id} value={c.name} />)}
            </datalist>
            {errors.companyName && <span className="text-[10px] text-red-600 font-bold">{errors.companyName}</span>}
          </div>

          {/* Contact Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#4E220F] mb-1">
                Phone Number
              </label>
              <input
                type="text"
                placeholder="+91 98765 43210"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl focus:ring-2 focus:ring-[#4E220F] outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#4E220F] mb-1">
                Email Address
              </label>
              <input
                type="email"
                placeholder="gomathi.hr@example.com"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl focus:ring-2 focus:ring-[#4E220F] outline-none"
              />
            </div>
          </div>

          {/* Company Requirements */}
          <div className="p-3 bg-white border border-[#C8A96B]/50 rounded-2xl space-y-3">
            <span className="text-xs font-bold text-[#4E220F] block">Recruitment Specifications</span>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-[#785642]">Students Required</label>
                <input
                  type="number"
                  value={formData.studentsRequired}
                  onChange={e => setFormData({ ...formData, studentsRequired: e.target.value })}
                  className="w-full text-xs p-2 border border-[#C8A96B] rounded-lg"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-[#785642]">Location</label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={e => setFormData({ ...formData, location: e.target.value })}
                  className="w-full text-xs p-2 border border-[#C8A96B] rounded-lg"
                />
              </div>
            </div>
            <div>
              <label className="block text-[11px] font-semibold text-[#785642]">Job Roles (comma separated)</label>
              <input
                type="text"
                placeholder="Software Engineer Trainee, QA Analyst"
                value={formData.jobRoles}
                onChange={e => setFormData({ ...formData, jobRoles: e.target.value })}
                className="w-full text-xs p-2 border border-[#C8A96B] rounded-lg"
              />
            </div>
          </div>

          {/* Initial Follow Up Schedule */}
          <div className="p-3 bg-[#FAF4EB] border border-[#C8A96B]/50 rounded-2xl space-y-2">
            <span className="text-xs font-bold text-[#4E220F] block">Initial Follow-Up Schedule (Optional)</span>
            <div className="grid grid-cols-2 gap-2">
              <input
                type="date"
                value={formData.nextFollowUpDate}
                onChange={e => setFormData({ ...formData, nextFollowUpDate: e.target.value })}
                className="w-full text-xs p-2 border border-[#C8A96B] rounded-lg bg-white"
              />
              <input
                type="text"
                value={formData.nextFollowUpTime}
                onChange={e => setFormData({ ...formData, nextFollowUpTime: e.target.value })}
                className="w-full text-xs p-2 border border-[#C8A96B] rounded-lg bg-white"
                placeholder="10:30 AM"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-[#785642]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#4E220F] hover:bg-[#7A3517] text-[#F3CD97] font-bold text-xs rounded-xl shadow-md"
            >
              ✓ Save HR Contact
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
