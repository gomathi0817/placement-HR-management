import React, { useState } from 'react';
import { X, Clock, Calendar, AlertCircle, Bell } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { getTodayDateString, isDateInPast, isDateTimeInPast } from '../../utils/dateUtils';

export const ScheduleFollowUpModal = ({ isOpen, onClose, defaultHrId = '' }) => {
  const { hrs, scheduleFollowUp } = useApp();

  const todayStr = getTodayDateString();
  const [selectedHrId, setSelectedHrId] = useState(defaultHrId || (hrs[0] ? hrs[0].id : ''));
  const [date, setDate] = useState(todayStr);
  const [time, setTime] = useState('10:30 AM');
  const [purpose, setPurpose] = useState('Discuss campus recruitment process');
  const [priority, setPriority] = useState('High');
  const [notes, setNotes] = useState('');
  const [enableReminder, setEnableReminder] = useState(true);
  const [reminderLeadTime, setReminderLeadTime] = useState('15 minutes before');
  const [validationError, setValidationError] = useState('');

  if (!isOpen) return null;

  const currentHR = hrs.find(h => h.id === selectedHrId) || hrs[0];

  const handleSubmit = async (e) => {
    e.preventDefault();
    setValidationError('');

    if (!purpose.trim()) {
      setValidationError('Purpose is required.');
      return;
    }

    // Strict Frontend Date & Time Validation
    if (isDateInPast(date)) {
      setValidationError('Follow-up date and time cannot be in the past.');
      return;
    }

    if (isDateTimeInPast(date, time)) {
      setValidationError('Follow-up date and time cannot be in the past.');
      return;
    }

    try {
      await scheduleFollowUp({
        hrId: currentHR ? currentHR.id : '',
        hrName: currentHR ? currentHR.name : '',
        companyName: currentHR ? currentHR.companyName : '',
        date,
        time,
        purpose,
        priority,
        notes: notes + (enableReminder ? ` [Reminder: ${reminderLeadTime}]` : '')
      });
      onClose();
    } catch (err) {
      setValidationError(err.response?.data?.message || 'Follow-up date and time cannot be in the past.');
    }
  };

  const leadTimes = [
    'At scheduled time',
    '15 minutes before',
    '30 minutes before',
    '1 hour before',
    '1 day before'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white border-2 border-[#4E220F] rounded-3xl max-w-md w-full overflow-hidden shadow-gv-modal flex flex-col">
        {/* Header */}
        <div className="bg-[#4E220F] text-[#F3CD97] p-5 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-[#F3CD97] text-[#4E220F] flex items-center justify-center font-bold">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base">Schedule Follow-Up</h3>
              <span className="text-[11px] text-[#F3CD97]/80">Set reminder & priority alert</span>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 overflow-y-auto bg-[#FAF4EB]/40 flex-1">
          {validationError && (
            <div className="p-3 bg-red-100 border border-red-300 text-red-900 text-xs font-bold rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-700" />
              <span>{validationError}</span>
            </div>
          )}

          {/* Target HR */}
          <div>
            <label className="block text-xs font-bold text-[#4E220F] mb-1">
              Select HR Contact
            </label>
            <select
              value={selectedHrId}
              onChange={e => setSelectedHrId(e.target.value)}
              className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl font-bold text-[#4E220F] outline-none"
            >
              {hrs.map(h => (
                <option key={h.id} value={h.id}>
                  {h.name} — {h.companyName}
                </option>
              ))}
            </select>
          </div>

          {/* Date & Time Pickers */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-[#4E220F] mb-1">
                Follow-Up Date <span className="text-red-600">*</span>
              </label>
              <input
                type="date"
                required
                min={todayStr}
                value={date}
                onChange={e => {
                  setDate(e.target.value);
                  setValidationError('');
                }}
                className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl outline-none font-bold text-[#4E220F]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#4E220F] mb-1">
                Time <span className="text-red-600">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="10:30 AM"
                value={time}
                onChange={e => {
                  setTime(e.target.value);
                  setValidationError('');
                }}
                className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl outline-none font-bold text-[#4E220F]"
              />
            </div>
          </div>

          {/* Follow Up Purpose */}
          <div>
            <label className="block text-xs font-bold text-[#4E220F] mb-1">
              Purpose / Goal <span className="text-red-600">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Discuss campus recruitment process"
              value={purpose}
              onChange={e => setPurpose(e.target.value)}
              className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl outline-none font-semibold text-[#4E220F]"
            />
          </div>

          {/* Priority Options */}
          <div>
            <label className="block text-xs font-bold text-[#4E220F] mb-1">
              Priority Level
            </label>
            <div className="grid grid-cols-3 gap-2">
              {['Low', 'Medium', 'High'].map(p => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className={`
                    py-2 rounded-xl text-xs font-bold border transition-all
                    ${priority === p 
                      ? p === 'High' 
                        ? 'bg-red-600 text-white border-red-700 shadow-xs' 
                        : p === 'Medium' 
                          ? 'bg-amber-600 text-white border-amber-700 shadow-xs' 
                          : 'bg-blue-600 text-white border-blue-700 shadow-xs'
                      : 'bg-white text-[#785642] border-[#C8A96B]/50 hover:bg-[#FAF4EB]'
                    }
                  `}
                >
                  {p} Priority
                </button>
              ))}
            </div>
          </div>

          {/* Additional Notes */}
          <div>
            <label className="block text-xs font-bold text-[#4E220F] mb-1">
              Additional Preparation Notes
            </label>
            <textarea
              rows={2}
              placeholder="Check auditorium booking status before calling..."
              value={notes}
              onChange={e => setNotes(e.target.value)}
              className="w-full text-xs p-3 bg-white border border-[#C8A96B] rounded-xl outline-none"
            />
          </div>

          {/* Smart Reminder Toggle */}
          <div className="p-3 bg-white border border-[#C8A96B]/50 rounded-2xl space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#4E220F]" />
                <span className="text-xs font-bold text-[#4E220F]">Enable Smart Alert Reminder</span>
              </div>
              <input
                type="checkbox"
                checked={enableReminder}
                onChange={e => setEnableReminder(e.target.checked)}
                className="w-4 h-4 accent-[#4E220F] cursor-pointer"
              />
            </div>

            {enableReminder && (
              <div>
                <label className="block text-[11px] font-semibold text-[#785642] mb-1">
                  Reminder Lead-Time
                </label>
                <select
                  value={reminderLeadTime}
                  onChange={e => setReminderLeadTime(e.target.value)}
                  className="w-full text-xs p-2 bg-[#FAF4EB] border border-[#C8A96B] rounded-lg font-bold text-[#4E220F]"
                >
                  {leadTimes.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            )}
          </div>

          <div className="pt-2 flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-bold text-[#785642]"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-[#4E220F] hover:bg-[#7A3517] text-[#F3CD97] font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5"
            >
              <Clock className="w-4 h-4" />
              <span>Schedule Follow-Up</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
