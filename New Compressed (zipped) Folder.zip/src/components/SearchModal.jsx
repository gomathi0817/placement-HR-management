import React, { useState, useEffect } from 'react';
import { Search, X, Users, Building2, Clock, MessageSquare, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useNavigate } from 'react-router-dom';

export const SearchModal = ({ isOpen, onClose }) => {
  const { hrs, companies, followUps, interactions } = useApp();
  const navigate = useNavigate();

  const [query, setQuery] = useState('');

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else setQuery('');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const matchedHRs = query.trim() ? hrs.filter(h =>
    h.name.toLowerCase().includes(query.toLowerCase()) ||
    h.companyName.toLowerCase().includes(query.toLowerCase()) ||
    h.designation.toLowerCase().includes(query.toLowerCase())
  ) : hrs.slice(0, 3);

  const matchedCompanies = query.trim() ? companies.filter(c =>
    c.name.toLowerCase().includes(query.toLowerCase()) ||
    c.industry.toLowerCase().includes(query.toLowerCase())
  ) : companies.slice(0, 3);

  const matchedFollowUps = query.trim() ? followUps.filter(f =>
    f.hrName.toLowerCase().includes(query.toLowerCase()) ||
    f.companyName.toLowerCase().includes(query.toLowerCase()) ||
    f.purpose.toLowerCase().includes(query.toLowerCase())
  ) : followUps.slice(0, 2);

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/60 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white border-2 border-[#4E220F] rounded-3xl max-w-xl w-full overflow-hidden shadow-gv-modal flex flex-col max-h-[80vh]">
        {/* Search Input Header */}
        <div className="p-4 border-b-2 border-[#C8A96B]/40 bg-[#FAF4EB] flex items-center gap-3">
          <Search className="w-5 h-5 text-[#4E220F]" />
          <input
            type="text"
            autoFocus
            placeholder="Global Search HR, Company, Purpose... (Press ESC to close)"
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full bg-transparent text-sm font-bold text-[#4E220F] outline-none placeholder:text-[#785642]/60"
          />
          <button onClick={onClose} className="p-1 text-[#785642] hover:text-[#4E220F]">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="p-4 space-y-4 overflow-y-auto flex-1">
          {/* HR Contacts Category */}
          {matchedHRs.length > 0 && (
            <div>
              <span className="text-[10px] font-black uppercase text-[#785642] tracking-wider block mb-2">
                HR Contacts ({matchedHRs.length})
              </span>
              <div className="space-y-1.5">
                {matchedHRs.map(h => (
                  <div
                    key={h.id}
                    onClick={() => {
                      navigate(`/hr/${h.id}`);
                      onClose();
                    }}
                    className="p-3 bg-[#FAF4EB] hover:bg-[#F3CD97]/30 rounded-xl border border-[#C8A96B]/30 flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#4E220F] text-[#F3CD97] flex items-center justify-center font-bold text-xs">
                        <Users className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-[#4E220F]">{h.name}</h4>
                        <span className="text-[11px] text-[#785642] font-semibold">{h.companyName} • {h.designation}</span>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#4E220F]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Companies Category */}
          {matchedCompanies.length > 0 && (
            <div>
              <span className="text-[10px] font-black uppercase text-[#785642] tracking-wider block mb-2">
                Recruiting Companies ({matchedCompanies.length})
              </span>
              <div className="space-y-1.5">
                {matchedCompanies.map(c => (
                  <div
                    key={c.id}
                    onClick={() => {
                      navigate(`/companies`);
                      onClose();
                    }}
                    className="p-3 bg-[#FAF4EB] hover:bg-[#F3CD97]/30 rounded-xl border border-[#C8A96B]/30 flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-[#C8A96B] text-[#4E220F] flex items-center justify-center font-bold text-xs">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-[#4E220F]">{c.name}</h4>
                        <span className="text-[11px] text-[#785642] font-semibold">{c.industry} • {c.location}</span>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#4E220F]" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Follow-Ups Category */}
          {matchedFollowUps.length > 0 && (
            <div>
              <span className="text-[10px] font-black uppercase text-[#785642] tracking-wider block mb-2">
                Follow-Up Reminders ({matchedFollowUps.length})
              </span>
              <div className="space-y-1.5">
                {matchedFollowUps.map(f => (
                  <div
                    key={f.id}
                    onClick={() => {
                      navigate(`/follow-ups`);
                      onClose();
                    }}
                    className="p-3 bg-[#FAF4EB] hover:bg-[#F3CD97]/30 rounded-xl border border-[#C8A96B]/30 flex items-center justify-between cursor-pointer transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-900 flex items-center justify-center font-bold text-xs border border-amber-300">
                        <Clock className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-[#4E220F]">{f.hrName} ({f.companyName})</h4>
                        <span className="text-[11px] text-[#785642] font-semibold">"{f.purpose}" • {f.date}</span>
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-[#4E220F]" />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
