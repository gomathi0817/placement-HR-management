import api from './api';

export const hrService = {
  getAll: async (search = '', status = '') => {
    const params = {};
    if (search) params.search = search;
    if (status && status !== 'All') params.status = status;
    const response = await api.get('/hr', { params });
    return response.data;
  },

  getById: async (id) => {
    const response = await api.get(`/hr/${id}`);
    return response.data;
  },

  create: async (hrData) => {
    const response = await api.post('/hr', hrData);
    return response.data;
  },

  update: async (id, hrData) => {
    const response = await api.put(`/hr/${id}`, hrData);
    return response.data;
  },

  delete: async (id) => {
    const response = await api.delete(`/hr/${id}`);
    return response.data;
  }
};
