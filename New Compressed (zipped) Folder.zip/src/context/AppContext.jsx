import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authService } from '../services/authService';
import { hrService } from '../services/hrService';
import { companyService } from '../services/companyService';
import { interactionService } from '../services/interactionService';
import { followUpService } from '../services/followUpService';
import { notificationService } from '../services/notificationService';
import { dashboardService } from '../services/dashboardService';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('gv_hr_user');
    return saved ? JSON.parse(saved) : {
      name: "Prof. R. Venkatesh",
      title: "Chief Placement Officer",
      department: "Training & Placement Cell",
      email: "placement@gvcollege.edu.in",
      phone: "+91 98400 12345",
      isLoggedIn: Boolean(localStorage.getItem('gv_token'))
    };
  });

  const [hrs, setHrs] = useState([]);
  const [companies, setCompanies] = useState([]);
  const [interactions, setInteractions] = useState([]);
  const [followUps, setFollowUps] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  // Active Reminder Modal state
  const [activeReminder, setActiveReminder] = useState(null);

  // Toast alert state
  const [toast, setToast] = useState(null);

  // Quick add menu modal state
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [activeModal, setActiveModal] = useState(null);

  const showToast = (message, type = 'success') => {
    setToast({ message, type, id: Date.now() });
    setTimeout(() => setToast(null), 3500);
  };

  // Fetch all backend REST API data
  const refreshAppData = useCallback(async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('gv_token');
      if (!token) {
        setLoading(false);
        return;
      }

      const [hrsData, compsData, intsData, folsData, notifsData] = await Promise.all([
        hrService.getAll().catch(() => []),
        companyService.getAll().catch(() => []),
        interactionService.getAll().catch(() => []),
        followUpService.getAll().catch(() => []),
        notificationService.getAll().catch(() => [])
      ]);

      setHrs(hrsData);
      setCompanies(compsData);
      setInteractions(intsData);
      setFollowUps(folsData);
      setNotifications(notifsData);
    } catch (err) {
      console.error("API Data fetch error:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    const token = localStorage.getItem('gv_token');
    if (token) {
      authService.getCurrentUser()
        .then(u => {
          setUser({ ...u, isLoggedIn: true });
          localStorage.setItem('gv_hr_user', JSON.stringify(u));
          refreshAppData();
        })
        .catch(() => {
          // Token invalid, user can login
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, [refreshAppData]);

  // Trigger active reminder popup after load
  useEffect(() => {
    if (followUps.length > 0 && !sessionStorage.getItem('gv_reminder_shown')) {
      const topFollowUp = followUps.find(f => f.status === 'Pending' || f.id === 'fol-1');
      if (topFollowUp) {
        const hr = hrs.find(h => h.id === topFollowUp.hrId) || {
          name: topFollowUp.hrName,
          companyName: topFollowUp.companyName,
          phone: "+91 98765 43210"
        };
        setActiveReminder({ followUp: topFollowUp, hr });
        sessionStorage.setItem('gv_reminder_shown', 'true');
      }
    }
  }, [followUps, hrs]);

  // Auth Functions
  const login = async (email, password) => {
    try {
      const res = await authService.login(email, password);
      setUser({ ...res.user, isLoggedIn: true });
      localStorage.setItem('gv_hr_user', JSON.stringify(res.user));
      showToast("Welcome back, Placement Officer! 👋");
      await refreshAppData();
      return res;
    } catch (err) {
      const msg = err.response?.data?.message || "Login failed. Please check credentials.";
      showToast(msg, "error");
      throw err;
    }
  };

  const logout = async () => {
    await authService.logout();
    setUser(prev => ({ ...prev, isLoggedIn: false }));
    setHrs([]);
    setCompanies([]);
    setFollowUps([]);
    setInteractions([]);
    showToast("Logged out successfully.", "info");
  };

  // CRUD API wrappers
  const addHR = async (newHRData) => {
    try {
      const createdHR = await hrService.create(newHRData);
      showToast(`✓ HR Contact "${createdHR.name}" created successfully in Database`);
      await refreshAppData();
      return createdHR;
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to save HR Contact", "error");
    }
  };

  const addInteraction = async (interactionData) => {
    try {
      const createdInt = await interactionService.create(interactionData);
      showToast("✓ Interaction saved to backend database");
      await refreshAppData();
      return createdInt;
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to log interaction", "error");
    }
  };

  const scheduleFollowUp = async (followUpData) => {
    try {
      const createdFol = await followUpService.create(followUpData);
      showToast(`✓ Follow-up scheduled with ${createdFol.hrName} in Database`);
      await refreshAppData();
      return createdFol;
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to schedule follow-up", "error");
    }
  };

  const markFollowUpComplete = async (followUpId) => {
    try {
      await followUpService.markCompleted(followUpId);
      showToast("✓ Follow-up marked as Completed in Database");
      await refreshAppData();
    } catch (err) {
      showToast("Failed to update status", "error");
    }
  };

  const rescheduleFollowUp = async (followUpId, newDate, newTime) => {
    try {
      await followUpService.reschedule(followUpId, newDate, newTime);
      showToast(`✓ Follow-up rescheduled to ${newDate} in Database`);
      await refreshAppData();
    } catch (err) {
      showToast("Failed to reschedule follow-up", "error");
    }
  };

  const addCompany = async (companyData) => {
    try {
      const createdComp = await companyService.create(companyData);
      showToast(`✓ Company profile "${createdComp.name}" created in Database`);
      await refreshAppData();
      return createdComp;
    } catch (err) {
      showToast(err.response?.data?.message || "Failed to save company", "error");
    }
  };

  return (
    <AppContext.Provider value={{
      user,
      hrs,
      companies,
      interactions,
      followUps,
      notifications,
      loading,
      activeReminder,
      setActiveReminder,
      toast,
      showToast,
      isQuickAddOpen,
      setIsQuickAddOpen,
      activeModal,
      setActiveModal,
      login,
      logout,
      addHR,
      addInteraction,
      scheduleFollowUp,
      markFollowUpComplete,
      rescheduleFollowUp,
      addCompany,
      refreshAppData
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
