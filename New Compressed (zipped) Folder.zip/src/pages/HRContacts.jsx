import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Search, Filter, Plus, Phone, Mail, Calendar, ArrowRight, User, CheckCircle2, Download } from 'lucide-react';
import { AddHRModal } from '../components/modals/AddHRModal';
import { EmailComposerModal } from '../components/modals/EmailComposerModal';
import { exportToCSV } from '../utils/exportUtils';

export const HRContacts = () => {
  const { hrs, setIsQuickAddOpen, showToast } = useApp();
  const navigate = useNavigate();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('All'); // All, Active, Waiting for Response
  const [isAddHRModalOpen, setIsAddHRModalOpen] = useState(false);
  const [emailTargetHR, setEmailTargetHR] = useState(null);

  // Filtered HR contacts
  const filteredHRs = hrs.filter(hr => {
    const matchesSearch = 
      hr.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hr.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hr.designation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      hr.phone.includes(searchTerm) ||
      hr.email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || hr.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const handleExportCSV = () => {
    const exportData = filteredHRs.map(h => ({
      "HR Name": h.name,
      "Company": h.companyName,
      "Designation": h.designation,
      "Phone": h.phone,
      "Email": h.email,
      "Status": h.status,
      "Last Contact": h.lastContactDate || '',
      "Next Follow-Up": h.nextFollowUpDate || '',
      "Students Required": h.companyInfo?.studentsRequired || 0,
      "Location": h.companyInfo?.location || ''
    }));

    exportToCSV(exportData, 'gv_hr_contacts_directory.csv');
    showToast("✓ HR Contacts directory exported to CSV!");
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 pb-24 lg:pb-12">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border-2 border-[#4E220F] rounded-3xl p-6 shadow-gv-card">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#4E220F]">
            HR Contacts Directory
          </h1>
          <p className="text-xs sm:text-sm font-semibold text-[#785642] mt-1">
            Manage placement recruiters, contacts, and relationship statuses.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleExportCSV}
            className="px-4 py-3 bg-[#FAF4EB] hover:bg-[#F3CD97]/40 text-[#4E220F] border border-[#C8A96B] font-bold text-xs rounded-2xl shadow-xs flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          <button
            onClick={() => setIsAddHRModalOpen(true)}
            className="px-5 py-3 bg-[#4E220F] hover:bg-[#7A3517] text-[#F3CD97] font-bold text-xs rounded-2xl shadow-md flex items-center justify-center gap-2 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>+ Add HR Contact</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white border-2 border-[#C8A96B]/50 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row gap-3 items-center justify-between">
        {/* Search Input */}
        <div className="relative w-full sm:w-96">
          <Search className="w-4 h-4 text-[#785642] absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search HR, company or designation..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full text-xs font-semibold pl-10 pr-4 py-2.5 bg-[#FAF4EB] border border-[#C8A96B] rounded-xl focus:ring-2 focus:ring-[#4E220F] outline-none text-[#4E220F]"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
          <Filter className="w-4 h-4 text-[#785642] flex-shrink-0" />
          {['All', 'Active', 'Waiting for Response'].map(st => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`
                px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border
                ${statusFilter === st
                  ? 'bg-[#4E220F] text-[#F3CD97] border-[#4E220F] shadow-xs'
                  : 'bg-[#FAF4EB] text-[#785642] border-[#C8A96B]/40 hover:bg-[#F3CD97]/30'
                }
              `}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* HR Cards Grid */}
      {filteredHRs.length === 0 ? (
        <div className="bg-white border-2 border-dashed border-[#C8A96B]/60 rounded-3xl p-12 text-center my-6 space-y-3">
          <User className="w-12 h-12 text-[#C8A96B] mx-auto" />
          <h3 className="text-base font-bold text-[#4E220F]">No HR Contacts Found</h3>
          <p className="text-xs text-[#785642]">
            Start building your professional recruitment network by adding your first HR lead.
          </p>
          <button
            onClick={() => setIsAddHRModalOpen(true)}
            className="px-5 py-2.5 bg-[#4E220F] text-[#F3CD97] font-bold text-xs rounded-xl shadow inline-flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add HR Contact</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredHRs.map(hr => (
            <div
              key={hr.id}
              onClick={() => navigate(`/hr/${hr.id}`)}
              className="bg-white hover:bg-[#FAF4EB]/60 border-2 border-[#C8A96B]/50 hover:border-[#4E220F] rounded-3xl p-5 cursor-pointer transition-all shadow-xs hover:shadow-md group flex flex-col justify-between space-y-4"
            >
              <div>
                {/* Header Row */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={hr.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200"}
                      alt={hr.name}
                      className="w-12 h-12 rounded-2xl object-cover border-2 border-[#C8A96B]"
                    />
                    <div>
                      <h3 className="font-extrabold text-base text-[#4E220F] group-hover:text-[#7A3517] leading-tight">
                        {hr.name}
                      </h3>
                      <p className="text-xs font-bold text-[#785642]">
                        {hr.companyName}
                      </p>
                      <span className="text-[11px] text-[#785642] block font-medium">
                        {hr.designation}
                      </span>
                    </div>
                  </div>

                  <span className={`
                    text-[10px] font-extrabold px-2.5 py-1 rounded-full border whitespace-nowrap
                    ${hr.status === 'Active' ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-purple-100 text-purple-800 border-purple-300'}
                  `}>
                    {hr.status}
                  </span>
                </div>

                {/* Contact Chips */}
                <div className="space-y-1.5 text-xs text-[#2D1409] bg-[#FAF4EB] p-3 rounded-2xl border border-[#C8A96B]/30">
                  <div className="flex items-center gap-2">
                    <Phone className="w-3.5 h-3.5 text-[#4E220F]" />
                    <span className="font-semibold">{hr.phone}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 truncate">
                      <Mail className="w-3.5 h-3.5 text-[#4E220F] flex-shrink-0" />
                      <span className="font-semibold truncate">{hr.email}</span>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setEmailTargetHR(hr);
                      }}
                      className="text-[10px] font-bold text-[#7A3517] hover:underline bg-white px-2 py-0.5 rounded border border-[#C8A96B]/30"
                    >
                      Draft Email
                    </button>
                  </div>
                </div>
              </div>

              {/* Footer Follow-up details */}
              <div className="pt-3 border-t border-[#C8A96B]/30 flex items-center justify-between text-xs">
                <div>
                  <span className="text-[10px] font-bold text-[#785642] uppercase tracking-wider block">
                    Next Follow-Up
                  </span>
                  <span className="font-extrabold text-[#4E220F] flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-[#C8A96B]" />
                    {hr.nextFollowUpDate || 'Not scheduled'}
                  </span>
                </div>

                <div className="w-8 h-8 rounded-xl bg-[#4E220F] text-[#F3CD97] flex items-center justify-center group-hover:translate-x-1 transition-transform">
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add HR Modal */}
      <AddHRModal isOpen={isAddHRModalOpen} onClose={() => setIsAddHRModalOpen(false)} />

      {/* Email Composer Modal */}
      <EmailComposerModal
        isOpen={Boolean(emailTargetHR)}
        onClose={() => setEmailTargetHR(null)}
        hr={emailTargetHR}
      />
    </div>
  );
};
