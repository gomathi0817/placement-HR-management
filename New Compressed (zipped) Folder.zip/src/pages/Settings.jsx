import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { User, Bell, Palette, Database, LogOut, Shield, RefreshCw, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export const Settings = () => {
  const { user, logout, resetToDemoData } = useApp();
  const navigate = useNavigate();

  const [reminderLeadTime, setReminderLeadTime] = useState('15 minutes before');
  const [soundAlerts, setSoundAlerts] = useState(true);
  const [emailDigest, setEmailDigest] = useState(true);

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 pb-24 lg:pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border-2 border-[#4E220F] rounded-3xl p-6 shadow-gv-card">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-[#4E220F]">
            System Settings & Preferences
          </h1>
          <p className="text-xs sm:text-sm font-semibold text-[#785642] mt-1">
            Officer profile configuration, reminder lead-times, and demo data controls.
          </p>
        </div>

        <button
          onClick={() => {
            logout();
            navigate('/login');
          }}
          className="px-5 py-2.5 bg-red-700 hover:bg-red-800 text-white font-bold text-xs rounded-2xl shadow flex items-center justify-center gap-2 transition-all self-start sm:self-auto"
        >
          <LogOut className="w-4 h-4" />
          <span>Logout</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Officer Profile Settings */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border-2 border-[#4E220F] rounded-3xl p-6 shadow-gv-card space-y-4">
            <div className="flex items-center gap-3 border-b border-[#C8A96B]/30 pb-4">
              <div className="w-12 h-12 rounded-2xl bg-[#4E220F] text-[#F3CD97] font-black flex items-center justify-center text-lg shadow">
                PO
              </div>
              <div>
                <h3 className="font-extrabold text-base text-[#4E220F]">{user.name}</h3>
                <p className="text-xs text-[#785642] font-semibold">{user.title} — {user.department}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-bold text-[#4E220F] mb-1">Official Email</label>
                <input
                  type="email"
                  disabled
                  value={user.email}
                  className="w-full p-3 bg-[#FAF4EB] border border-[#C8A96B]/50 rounded-xl font-bold text-[#4E220F]"
                />
              </div>

              <div>
                <label className="block font-bold text-[#4E220F] mb-1">Contact Phone</label>
                <input
                  type="text"
                  disabled
                  value={user.phone}
                  className="w-full p-3 bg-[#FAF4EB] border border-[#C8A96B]/50 rounded-xl font-bold text-[#4E220F]"
                />
              </div>
            </div>
          </div>

          {/* Reminder Preferences */}
          <div className="bg-white border-2 border-[#4E220F] rounded-3xl p-6 shadow-gv-card space-y-4">
            <div className="flex items-center gap-2 border-b border-[#C8A96B]/30 pb-3">
              <Bell className="w-5 h-5 text-[#4E220F]" />
              <h3 className="font-extrabold text-base text-[#4E220F]">Reminder Preferences</h3>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-[#4E220F] mb-1">Default Reminder Lead-Time</label>
                <select
                  value={reminderLeadTime}
                  onChange={e => setReminderLeadTime(e.target.value)}
                  className="w-full max-w-xs p-3 bg-[#FAF4EB] border border-[#C8A96B] rounded-xl font-bold text-[#4E220F]"
                >
                  <option value="At scheduled time">At scheduled time</option>
                  <option value="15 minutes before">15 minutes before</option>
                  <option value="30 minutes before">30 minutes before</option>
                  <option value="1 hour before">1 hour before</option>
                </select>
              </div>

              <div className="space-y-2 pt-2 border-t border-[#C8A96B]/20">
                <label className="flex items-center gap-3 cursor-pointer text-[#4E220F] font-bold">
                  <input
                    type="checkbox"
                    checked={soundAlerts}
                    onChange={e => setSoundAlerts(e.target.checked)}
                    className="w-4 h-4 accent-[#4E220F] rounded"
                  />
                  <span>Enable Audio Sound Chime on Active Alerts</span>
                </label>

                <label className="flex items-center gap-3 cursor-pointer text-[#4E220F] font-bold">
                  <input
                    type="checkbox"
                    checked={emailDigest}
                    onChange={e => setEmailDigest(e.target.checked)}
                    className="w-4 h-4 accent-[#4E220F] rounded"
                  />
                  <span>Daily Morning HR Summary Digest via Email</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Theme Token Inspector & Reset Data */}
        <div className="space-y-6">
          {/* Brand Theme Palette Specs */}
          <div className="bg-white border-2 border-[#4E220F] rounded-3xl p-6 shadow-gv-card space-y-4">
            <div className="flex items-center gap-2 border-b border-[#C8A96B]/30 pb-3">
              <Palette className="w-5 h-5 text-[#4E220F]" />
              <h3 className="font-extrabold text-base text-[#4E220F]">Brand Color Tokens</h3>
            </div>

            <div className="space-y-3 text-xs font-bold">
              <div className="flex items-center justify-between p-2.5 rounded-xl border border-[#C8A96B]/30 bg-[#FAF4EB]">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#4E220F] border border-black/20 shadow-xs" />
                  <span>Primary Dark / Brand</span>
                </div>
                <span className="font-mono text-[11px] text-[#4E220F]">#4E220F</span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl border border-[#C8A96B]/30 bg-[#FAF4EB]">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#F3CD97] border border-black/20 shadow-xs" />
                  <span>Primary Background</span>
                </div>
                <span className="font-mono text-[11px] text-[#4E220F]">#F3CD97</span>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-xl border border-[#C8A96B]/30 bg-[#FAF4EB]">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-[#C8A96B] border border-black/20 shadow-xs" />
                  <span>Secondary / Surface</span>
                </div>
                <span className="font-mono text-[11px] text-[#4E220F]">#C8A96B</span>
              </div>
            </div>
          </div>

          {/* Reset Demo Data Card */}
          <div className="bg-[#FAF4EB] border-2 border-[#C8A96B]/60 rounded-3xl p-6 shadow-gv-card space-y-3">
            <div className="flex items-center gap-2 text-[#4E220F]">
              <Database className="w-5 h-5" />
              <h3 className="font-extrabold text-base">Demo Data Controls</h3>
            </div>

            <p className="text-xs text-[#785642] font-semibold leading-relaxed">
              Restore initial seed HR contacts, companies, conversation timelines, and follow-ups.
            </p>

            <button
              onClick={resetToDemoData}
              className="w-full py-3 bg-[#4E220F] hover:bg-[#7A3517] text-[#F3CD97] font-bold text-xs rounded-xl shadow flex items-center justify-center gap-2 transition-all"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Reset to Initial Demo State</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
