import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Logo } from '../components/Logo';
import { useApp } from '../context/AppContext';
import { ArrowRight, ShieldCheck, CheckCircle2, Lock, Mail } from 'lucide-react';

export const Login = () => {
  const { login } = useApp();
  const navigate = useNavigate();

  const [email, setEmail] = useState('placement@gvcollege.edu.in');
  const [password, setPassword] = useState('placement2026');
  const [rememberMe, setRememberMe] = useState(true);

  const handleFormSubmit = (e) => {
    e.preventDefault();
    login(email, password);
    navigate('/dashboard');
  };

  const handleDemoLogin = () => {
    login('placement@gvcollege.edu.in', 'placement2026');
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-gv-bg flex items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      {/* Background Subtle Decorative Shapes */}
      <div className="absolute -top-20 -left-20 w-96 h-96 rounded-full bg-[#C8A96B]/20 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -right-20 w-96 h-96 rounded-full bg-[#4E220F]/10 blur-3xl pointer-events-none" />

      <div className="max-w-md w-full bg-white border-2 border-[#4E220F] rounded-3xl p-6 sm:p-8 shadow-gv-modal relative z-10">
        {/* Logo Header */}
        <div className="flex flex-col items-center text-center mb-8">
          <div className="mb-3">
            <Logo size="lg" showSubtitle={false} />
          </div>
          <h2 className="text-2xl font-black text-[#4E220F] tracking-tight">
            GV HR Follow-Up
          </h2>
          <p className="text-xs font-semibold text-[#785642] mt-1.5 max-w-xs">
            "Manage every HR conversation. Never miss a follow-up."
          </p>
        </div>

        {/* Login Form */}
        <form onSubmit={handleFormSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-[#4E220F] mb-1.5">
              Placement Officer Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#785642] absolute left-3.5 top-3.5" />
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full text-xs font-semibold pl-10 pr-4 py-3 bg-[#FAF4EB] border-2 border-[#C8A96B]/50 rounded-xl focus:border-[#4E220F] focus:bg-white outline-none transition-all text-[#4E220F]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-[#4E220F] mb-1.5">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#785642] absolute left-3.5 top-3.5" />
              <input
                type="password"
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full text-xs font-semibold pl-10 pr-4 py-3 bg-[#FAF4EB] border-2 border-[#C8A96B]/50 rounded-xl focus:border-[#4E220F] focus:bg-white outline-none transition-all text-[#4E220F]"
              />
            </div>
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-[#4E220F] font-semibold">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={e => setRememberMe(e.target.checked)}
                className="w-4 h-4 accent-[#4E220F] rounded cursor-pointer"
              />
              <span>Remember me</span>
            </label>

            <a href="#forgot" onClick={(e) => { e.preventDefault(); alert("Demo Mode: Click 'Login as Placement Officer' below."); }} className="font-bold text-[#7A3517] hover:underline">
              Forgot password?
            </a>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 bg-[#4E220F] hover:bg-[#7A3517] text-[#F3CD97] font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 group mt-2"
          >
            <span>Login to Management Dashboard</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </form>

        {/* Demo Fast Login Shortcut */}
        <div className="mt-6 pt-5 border-t border-[#C8A96B]/30 text-center">
          <span className="text-[11px] font-bold text-[#785642] uppercase tracking-wider block mb-2">
            Quick Demonstration Login
          </span>
          <button
            type="button"
            onClick={handleDemoLogin}
            className="w-full py-2.5 px-4 bg-[#FAF4EB] border-2 border-[#C8A96B] hover:bg-[#F3CD97]/30 text-[#4E220F] font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-all shadow-xs"
          >
            <ShieldCheck className="w-4 h-4 text-[#4E220F]" />
            <span>Login as Chief Placement Officer</span>
          </button>
        </div>

        {/* Footer info */}
        <div className="mt-6 text-center text-[10px] text-[#785642] font-semibold">
          GV Placement Cell • Dedicated Recruiter CRM Platform
        </div>
      </div>
    </div>
  );
};
