import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AppProvider, useApp } from './context/AppContext';
import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';

// Mobile Custom Hooks & Components
import useAndroidBackButton from './hooks/useAndroidBackButton';
import NetworkStatusBanner from './components/NetworkStatusBanner';

// Layout Components
import { Sidebar } from './components/Sidebar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { Header } from './components/Header';
import { Toast } from './components/Toast';
import { ReminderModal } from './components/ReminderModal';
import { QuickAddModal } from './components/QuickAddModal';
import { SearchModal } from './components/SearchModal';

// Modals
import { AddHRModal } from './components/modals/AddHRModal';
import { AddInteractionModal } from './components/modals/AddInteractionModal';
import { ScheduleFollowUpModal } from './components/modals/ScheduleFollowUpModal';
import { AddCompanyModal } from './components/modals/AddCompanyModal';

// Pages
import { Login } from './pages/Login';
import { Dashboard } from './pages/Dashboard';
import { HRContacts } from './pages/HRContacts';
import { HRProfile } from './pages/HRProfile';
import { FollowUps } from './pages/FollowUps';
import { CalendarView } from './pages/CalendarView';
import { Companies } from './pages/Companies';
import { Analytics } from './pages/Analytics';
import { Notifications } from './pages/Notifications';
import { Settings } from './pages/Settings';

const AppContent = () => {
  const { user, isQuickAddOpen, setIsQuickAddOpen } = useApp();
  const location = useLocation();

  // Handle native Android hardware back button
  useAndroidBackButton();

  // Set native status bar background color to brand dark (#4E220F)
  useEffect(() => {
    if (Capacitor.isNativePlatform()) {
      StatusBar.setStyle({ style: Style.Dark }).catch(() => {});
      StatusBar.setBackgroundColor({ color: '#4E220F' }).catch(() => {});
    }
  }, []);

  // Active quick add form modals & Search modal
  const [activeModal, setActiveModal] = useState(null); // 'addHR', 'addInteraction', 'scheduleFollowUp', 'addCompany'
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);

  const isLoginPage = location.pathname === '/login';

  const handleQuickAddOptionSelect = (optionId) => {
    setActiveModal(optionId);
  };

  if (isLoginPage) {
    return (
      <div className="min-h-screen bg-gv-bg font-sans pt-safe pb-safe">
        <NetworkStatusBanner />
        <Toast />
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gv-bg flex flex-col font-sans text-gv-textDark selection:bg-gv-dark selection:text-white pt-safe pb-safe">
      {/* Network Status Banner */}
      <NetworkStatusBanner />

      <div className="flex-1 flex w-full min-h-0">
        {/* Toast Alert */}
        <Toast />

        {/* Smart Reminder Modal */}
        <ReminderModal />

        {/* Global Search Modal */}
        <SearchModal
          isOpen={isSearchModalOpen}
          onClose={() => setIsSearchModalOpen(false)}
        />

        {/* Floating Quick Add Menu */}
        <QuickAddModal
          isOpen={isQuickAddOpen}
          onClose={() => setIsQuickAddOpen(false)}
          onSelectOption={handleQuickAddOptionSelect}
        />

        {/* Sub-form Modals triggered by Quick Add */}
        <AddHRModal
          isOpen={activeModal === 'addHR'}
          onClose={() => setActiveModal(null)}
        />

        <AddInteractionModal
          isOpen={activeModal === 'addInteraction'}
          onClose={() => setActiveModal(null)}
        />

        <ScheduleFollowUpModal
          isOpen={activeModal === 'scheduleFollowUp'}
          onClose={() => setActiveModal(null)}
        />

        <AddCompanyModal
          isOpen={activeModal === 'addCompany'}
          onClose={() => setActiveModal(null)}
        />

        {/* Desktop Sidebar Navigation */}
        <Sidebar />

        {/* Main Content Viewport */}
        <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
          <Header onSearchClick={() => setIsSearchModalOpen(true)} />

          <main className="flex-1">
            <Routes>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/hr" element={<HRContacts />} />
              <Route path="/hr/:id" element={<HRProfile />} />
              <Route path="/follow-ups" element={<FollowUps />} />
              <Route path="/calendar" element={<CalendarView />} />
              <Route path="/companies" element={<Companies />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </main>

          {/* Mobile Bottom Navigation */}
          <MobileBottomNav />
        </div>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

